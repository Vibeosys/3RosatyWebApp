<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Dto;

/**
 * Description of SubscriberPostSigninDetailsDto
 *
 * @author anand
 */
class SubscriberPostSigninDetailsDto {

    //put your code here
    public $subscriberId;
    public $name;
    public $nickName;
    public $sType;
    public $isSubscribed;
    public $subscriptionDate;
    public $telNo;
    public $mobileNo;
    public $websiteUrl;
    public $country;
}
