<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Dto;

/**
 * Description of SubscriberPortfolioListResponseDto
 *
 * @author anand
 */
class SubscriberPortfolioListResponseDto {
    //put your code here
    public $portfolioId;
    public $coverImageUrl;
    public $category;
    public $subCategory;
    public $minPrice;
    public $maxPrice;
    public $isActive;
}
