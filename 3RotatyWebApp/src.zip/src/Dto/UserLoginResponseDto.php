<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Dto;

/**
 * Description of UserLoginResponseDto
 *
 * @author anand
 */
class UserLoginResponseDto {
    //put your code here
    public $userId;
    public $firstName;
    public $lastName;
}
