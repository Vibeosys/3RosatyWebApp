<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Dto;

/**
 * Description of PortfolioEmailDetailsDto
 *
 * @author anand
 */
class PortfolioEmailDetailsDto {

    //put your code here
    public $subscriberName;
    public $subscriberPhone;
    public $subscriberEmail;
    public $subscriberType;
    public $contactPerson;
    public $category;
    public $subcategory;
    public $minPrice;
    public $maxPrice;
    public $coverImageUrl;

}
